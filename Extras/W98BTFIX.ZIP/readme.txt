
----------------------------------------------------------
JO.SYS not working with some Windows 98 bootable diskettes
----------------------------------------------------------

The bootsector code of some Windows 98 diskettes is different than is should 
be. To fix it just run "fix.bat" and your done.

Best regards,
Bart Lagerweij

http://www.nu2.nu
